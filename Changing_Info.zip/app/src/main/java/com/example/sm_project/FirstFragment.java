package com.example.sm_project;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class FirstFragment extends Fragment {
    EditText txt_shop_name, txt_shop_addr_first, txt_shop_addr_second, txt_shop_time;
    Button button_first;
    String uid;

    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener firebaseAuthListener;
    DatabaseReference mDatabase;
    FirebaseUser user;

    private Context context;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_first, container, false);

        //객체 초기화
        txt_shop_name = rootView.findViewById(R.id.txt_shop_name);
        txt_shop_addr_first = rootView.findViewById(R.id.txt_shop_addr_first);
        txt_shop_addr_second = rootView.findViewById(R.id.txt_shop_addr_second);
        txt_shop_time = rootView.findViewById(R.id.txt_shop_time);
        button_first = rootView.findViewById(R.id.button_first);

        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser(); //로그인한 유저의 정보 가져오기
        uid = user != null ? user.getUid() : null;

        context = container.getContext();

        mDatabase = FirebaseDatabase.getInstance().getReference();
        mDatabase.child("StoreInfo").child(uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(uid != null){
                    txt_shop_name.setText(snapshot.child("name").getValue(String.class));
                    txt_shop_addr_first.setText(snapshot.child("addrFirst").getValue(String.class));
                    txt_shop_addr_second.setText(snapshot.child("addrSecond").getValue(String.class));
                    txt_shop_time.setText(snapshot.child("time").getValue(String.class));
                }else {
                    Toast.makeText(context, "회원정보를 불러올수가 없습니다.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });

        button_first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!txt_shop_name.getText().toString().equals("") && !txt_shop_addr_first.getText().toString().equals("") && !txt_shop_addr_second.getText().toString().equals("") && !txt_shop_time.getText().toString().equals("")) {

                    String name = txt_shop_name.getText().toString().trim();
                    String addrFirst = txt_shop_addr_first.getText().toString().trim();
                    String addrSecond = txt_shop_addr_second.getText().toString().trim();
                    String time = txt_shop_time.getText().toString().trim();

                    HashMap<String, Object> childUpdates = new HashMap<>();

                    StoreInfo storeInfo = new StoreInfo(uid, name, addrFirst, addrSecond, time);
                    Map<String, Object> storeValue = storeInfo.toMap();

                    childUpdates.put("/StoreInfo/" + uid, storeValue);
                    mDatabase.updateChildren(childUpdates);

                    Toast.makeText(context, "수정되었습니다.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(context, MainActivity.class));
                } else {
                    Toast.makeText(context, "작성하지 않은 항목이 있습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return rootView;
    }

    /*public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.button_first).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(FirstFragment.this).navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });
    }*/
    public class StoreInfo {
        public String uid;
        public String name;
        public String addrFirst;
        public String addrSecond;
        public String time;

        public StoreInfo(){ }

        public StoreInfo(String uid ,String name, String addrFirst, String addrSecond, String time) {
            this.uid = uid;
            this.name = name;
            this.addrFirst = addrFirst;
            this.addrSecond = addrSecond;
            this.time = time;
        }

        public Map<String, Object> toMap() {
            HashMap<String, Object> result = new HashMap<>();
            result.put("uid", uid);
            result.put("name", name);
            result.put("addrFirst", addrFirst);
            result.put("addrSecond", addrSecond);
            result.put("time", time);

            return result;
        }
    }
}